package com.example;

import java.util.Scanner;

public class StringProcessor extends Payment{
    public static void main(String[] args) {
        task1(3, "hello");
        task6("Рост кирилла 0x10 метров");
        //task3();


    }

    public static String task1(int num, String a){

        try{
            System.out.println("Код 1");     
            String out = a.repeat(num);
            System.out.println(out);
            return out;
        } catch(IllegalArgumentException | java.util.InputMismatchException e){
            System.out.println("Не то, переделывай");
            //task1(num, a);
            return "no";
        } 
        
        

    }

    public static int task2(String a, String b){
        System.out.println("Код 2");
        //String a = "fff"; //Строка
        //String b = ""; // Подстрока
        int count = 0;
        int value = 0;
        if(b == "" || b == null){
            System.out.println("Недопустимое значение");
        } else{
            while (value < a.length()) {
                value = a.indexOf(b, value);
                if(value != -1){
                    count++;
                    value += b.length();
                } else{
                    break;
                }
            }
            System.out.println(count);
        }
        return count;
    }

    public static String task3(String a){
        System.out.println("Код 3");
        //String a = "123123123";
        a = a.replaceAll("1", "один");
        a = a.replaceAll("2", "два");
        a = a.replaceAll("3", "три");
        System.out.println(a);
        return a;
    }

    public static String task4(String aa){
        System.out.println("Код 4");
        StringBuilder a = new StringBuilder(aa);
        for (int i = 1; i < a.length(); i++)
            a.deleteCharAt(i);
        System.out.println(a);
        String aaa = a.toString();
        return aaa;

    }

    public static String task5(String str){
        System.out.println("Код 5");
        //String str = "Im Slim Shady yes im the real    Shady";
        String str2 = "";
        String[] words = str.split(" ");
        for (int i = words.length; i > 0; i--)
            str2 = str2 + words[i-1] + " ";
        System.out.println(str2);
        return str2;
    }

    public static String task6(String aa){
        System.out.println("Код 6");
        StringBuilder a = new StringBuilder(aa);
        int start = a.indexOf("0x");
        a.append(" ");
        a.replace(start, a.indexOf(" ", start), Integer.toString(Integer.parseInt(a.substring(start+2, a.indexOf(" ", start)),16)));
        //a.deleteCharAt(-1);
        System.out.println(a);
        return a.toString();
        
    }

    public static void task7(){
        Payment user1;
        user1 = new Payment();
        user1.Constructor("Черенков Кирилл Денисович", 11, 1, 2023, 12000);
        
        Payment user2;
        user2 = new Payment();
        user2.Constructor("Черенков Кирилл Денисович", 11, 1, 2023, 12000);
        

        if (user1.hashCode() == user2.hashCode()){
            System.out.println(user1.equals(user2));
        } else{
            System.out.println(false);
        }
        System.out.println(user1.toString());
    }
}












