package com.example;

import java.util.ArrayList;
import java.util.Arrays;

public class task13 extends spravkaclass{
    static ArrayList<spravkaclass> spravkiList = new ArrayList<spravkaclass>();
    static int[][] financematrix = new int[12][4];
         
    public static void main(String[] args) {
        
        //Добавляем справки и задаем значения конструкторами
        spravkiList.add(new spravkaclass());
        spravkiList.get(0).Constructor(2020, "Черенков Кирилл Денисович", "ООО Тсоси", 12000, 12000, 12000, 12000, 12000, 12000, 12000, 12000, 12000, 12000, 12000, 12000);
        
        spravkiList.add(new spravkaclass());
        spravkiList.get(1).Constructor(2020, "Черенков Кирилл Денисович", "ООО Тсосал", 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200);

        //Тут функции
        fillDeclaration();
        getSomething(1,1);
        getDeclaration();
        getCollumn(2);
        getNalog();
        spravkiList.get(0).getMoneyFromSpravka();
    }

    //МЕТОДЫ!!!

    //Выводит что то
    public static void getSomething(int a, int b){
        System.out.println(financematrix[a][b]);
    }

    //Выводит декларацию ввиде таблицы
    public static void getDeclaration(){
        System.out.println("Месяц | Доход | Годовой доход | Налог");
        for(int t = 0; t < 12; t++){
            System.out.print(financematrix[t][0]+"  ");
            System.out.print(financematrix[t][1]+"  ");
            System.out.print(financematrix[t][2]+"  ");
            System.out.println(financematrix[t][3]+"  ");  
        }
    }

    public static void fillDeclaration(){
        //заполняет месяца от 1 до 12
        for(int k = 0; k < 12; k++){
            financematrix[k][0] = k + 1;
        }        
       
        //заполняет 2 и 3 колонку с доходом за месяц и общим за год
        for(int i = 0; i < 12; i++){   
            for(int m = 0; m < spravkiList.size(); m++){
                financematrix[i][1] += spravkiList.get(m).GMM(m);
            }
            if(i == 0){
                financematrix[i][2] = financematrix[i][1];
            } else{
                financematrix[i][2] = financematrix[i][1] + financematrix[i-1][2];
            }
        }

        //вычисляет налог
        for(int j = 0; j < 12; j++){
            if(financematrix[j][2] <= 24000){
                financematrix[j][3] = 0;
            } else if (financematrix[j][2] > 24000 && financematrix[j][2] < 240000){
                financematrix[j][3] = (int) ((financematrix[j][2] - 24000) * 0.13);
            } else if (financematrix[j][2] > 240000){
                financematrix[j][3] = (int) ((financematrix[j][2] - 240000) * 0.2);
            }
        }
    }

    //Выводит массив из колонки таблицы
    public static void getCollumn(int a){
        int[] collumn = new int[12];
        for(int i = 0; i < 12; i++){
            collumn[i] = financematrix[i][a];
        }
        System.out.println(Arrays.toString(collumn));
    }

    //Выводит итоговый налог за год
    public static void getNalog(){
        int itogNalog = 0;
        for(int i = 0; i < 12; i++){
            itogNalog += financematrix[i][3];
        }
        System.out.println("Итоговый налог: " + itogNalog);
    }
}