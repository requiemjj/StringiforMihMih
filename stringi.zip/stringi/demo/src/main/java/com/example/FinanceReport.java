package com.example;

import java.util.ArrayList;
import java.util.Arrays;

public class FinanceReport extends Payment{
    static ArrayList<Payment> paymentarray = new ArrayList<Payment>();
    static String ReportCreatorName = "Алмаз";
    static String ReportCreatorDate = "20.10.2024";
    
    public static void AddPay(){
        paymentarray.add(new Payment());

    }

    public static void getPay(int i){
        System.out.println(paymentarray.get(i).toString());
    }

    public static void PaymentCount(){
        System.out.println(paymentarray.size());
    }

    public static void ArrayToString(){
        System.out.println(String.format("Автор: %s Дата: %s Платежи:", ReportCreatorName, ReportCreatorDate));
        for(int i = 0; i < paymentarray.size(); i++){
            getPay(i);
        }
    }

    public static void FirstChar(){
        char ch = 'Ч';
        for(int i = 0; i < paymentarray.size(); i++){
            if(paymentarray.get(i).getFio().charAt(0) == ch){
                System.out.println(paymentarray.get(i).toString());
            }
        }
    }

    public static void sumdate(String date){
        int sumcoast = 0;
        for(int i = 0; i < paymentarray.size(); i++){
            if(paymentarray.get(i).getDate().equals(date)){
                sumcoast += paymentarray.get(i).getCoast();
            }
        }
        System.out.println(sumcoast);
    }
    //Месяцы, в которых не было ни одного платежа в течение этого года. 12 задание
    public static void hollowmonth(int yearr){
        ArrayList<String> months = new ArrayList<>();
        months.add("Январь");
        months.add("Февраль");
        months.add("Март");
        months.add("Апрель");
        months.add("Май");
        months.add("Июнь");
        months.add("Июль");
        months.add("Август");
        months.add("Сентябрь");
        months.add("Октябрь");
        months.add("Ноябрь");
        months.add("Декабрь");
        ArrayList<String> months2 = new ArrayList<>();
        for(int i = 0; i < paymentarray.size(); i++){
            if(paymentarray.get(i).getYear() == yearr){
                months2.add(months.get(paymentarray.get(i).getMonth()-1));
            }
        }
        months.removeAll(months2);
        System.out.println(months);
    }

    public static void main(String[] args) {
        AddPay();
        AddPay();
        AddPay();
        AddPay();

        paymentarray.get(0).Constructor("Черенков Кирилл Романович", 11, 1, 2023, 12000);
        paymentarray.get(1).Constructor("Судейкин Евгений Кириллович", 12, 2, 2022, 22000);
        paymentarray.get(2).Constructor("Старокожев Максим Евгеньивич", 13, 3, 2022, 212000);
        paymentarray.get(3).Constructor("Золоташко Роман Кириллович", 14, 1, 2023, 12000);
        
        getPay(0);
        PaymentCount();

        //Отчёт. 9 задание
        ArrayToString();
        //Копия. 10 задание
        ArrayList<Payment> paymentarraycopy = new ArrayList<Payment>();
        paymentarraycopy.addAll(paymentarray);

        //Поиск по 1 символу. 11 задание
        FirstChar();
        //Общий платеж на дату. 12 задание (1)
        sumdate("11.1.2023");
        hollowmonth(2022);
    }

}
