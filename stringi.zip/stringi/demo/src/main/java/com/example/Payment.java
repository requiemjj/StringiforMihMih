package com.example;

import java.util.Objects;

public class Payment {
   
    private String fio;
    private int day;
    private int month;
    private int year;
    private int coast;
    
    public void Constructor(String fio, int day, int month, int year, int coast){
        this.fio = fio;
        this.day = day;
        this.month = month;
        this.year = year;
        this.coast = coast;
    }

    //Сетеры
    public void setFio(String fio){
        this.fio = fio;
    }
    
    public void setDay(int day){
        this.day = day;
    }

    public void setMonth(int month){
        this.month = month;
    }

    public void setYear(int year){
        this.year = year;
    }

    public void setCoast(int coast){
        this.coast = coast;
    }

    //Гетеры

    public String getFio(){
        return fio;
    }

    public int getDay(){
        return day;
    }

    public int getMonth(){
        return month;
    }

    public int getYear(){
        return year;
    }
    public int getCoast(){
        return coast;
    }

    public String getDate(){
        return day+"."+month+"."+year;
    }

    public String toString() {
        return "Дата: " + day + "." + month + "." + year + " Имя: " + fio + " Цена: " + coast/100 + " рублей.";
    }


    //Сравнения

    @Override
    public int hashCode() {
        return Objects.hash(coast, day, fio, month, year);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Payment user = (Payment) o;
        return day == user.day &&
               month == user.month &&
               year == user.year &&
               coast == user.coast &&
               fio.equals(user.fio);
    }

    
    public static void main(String[] args) {
    }
}
