package com.example;

import java.util.Arrays;

public class spravkaclass {
    private int year;
    private String FIO;
    private String org;
    private int[][] spravka = new int[12][2]; 

    //Ну конструктор для справок, понятно
    public void Constructor(int year, String FIO, String org, int Jan, int Feb, int Mar, int Apr, int May, int Jun, int Jul, int Aug, int Sep, int Oct, int Nov, int Dec){
        //Заполняет 1 колонку от 1 до 12
        for(int i = 0; i < 12; i++){
            spravka[i][0] = i + 1;
        }

        this.year = year;
        this.FIO = FIO;
        this.org = org;
        spravka[0][1] = Jan;
        spravka[1][1] = Feb;
        spravka[2][1] = Mar;
        spravka[3][1] = Apr;
        spravka[4][1] = May;
        spravka[5][1] = Jun;
        spravka[6][1] = Jul;
        spravka[7][1] = Aug;
        spravka[8][1] = Sep;
        spravka[9][1] = Oct;
        spravka[10][1] = Nov;
        spravka[11][1] = Dec;
    }

    //Не помню че это, но вроде деньги за месяц, зачем то нужен
    public int GMM(int m){
        return spravka[m][1];
    }

    //Выводит деньги из справки массивом
    public void getMoneyFromSpravka(){
        int[] SpravkaMoney = new int[12];
        for(int i = 0; i < 12; i++){
            SpravkaMoney[i] = GMM(i);//пригодилось
        }
        System.out.println(Arrays.toString(SpravkaMoney));
    }
}