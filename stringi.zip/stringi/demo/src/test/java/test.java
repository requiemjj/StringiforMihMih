import org.junit.jupiter.api.Test;

import com.example.StringProcessor;

import static org.junit.jupiter.api.Assertions.*;

 
public class test {
    @Test
    public void task1test(){
        StringProcessor SP = new StringProcessor();
        String result = SP.task1(3, "hello");
        assertEquals("hellohellohello", result);
    }
    
    @Test
    public void task2test(){
        StringProcessor SP = new StringProcessor();
        int result = SP.task2("hellohellohello", "hello");
        assertEquals(3, result);
    }

    @Test
    public void task3test(){
        StringProcessor SP = new StringProcessor();
        String result = SP.task3("123123123");
        assertEquals("одиндватриодиндватриодиндватри", result);
    }

    @Test
    public void task4test(){
        StringProcessor SP = new StringProcessor();
        String result = SP.task4("aabbccdd");
        assertEquals("abcd", result);
    }

    @Test
    public void task5test(){
        StringProcessor SP = new StringProcessor();
        String result = SP.task5("aa bb cc dd");
        assertEquals("dd cc bb aa ", result);
    }

    @Test
    public void task6test(){
        StringProcessor SP = new StringProcessor();
        String result = SP.task6("Рост кирилла 0x10 метров");
        assertEquals("Рост кирилла 16 метров ", result);
    }
}